/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class hanhchinh extends nhanvien {

    public hanhchinh() {
    }


    public hanhchinh(String maNV,String  hoTen, String loai, float luong) 
    {
     super(maNV,hoTen,"hanhchinh",luong);
    }
    
    
}