package assignment;

import java.util.Scanner;

 public class tiepthi extends nhanvien
 {
    public float doanhSo;
    public float hoaHong;

    public tiepthi() {
    }
    
     public tiepthi (String maNV,String  hoTen, String loai, float luong,float doanhSo,float hoaHong)
    {
        super(maNV,hoTen,"tiepthi",luong);
        this.doanhSo= doanhSo;
        this.hoaHong= hoaHong;
    }

      public void nhap(Scanner abc)
         {
             super.nhap(abc);
             System.out.println("Doanh so");
             this.doanhSo= abc.nextFloat();
             System.out.println("Hoa hong");
             this.hoaHong=abc.nextFloat();
             abc.nextFloat();
             
         }
      public void xuat(){
      super.xuat();
          System.out.printf("doanh so : %f   ; hoa hong : %f  ",doanhSo,hoaHong);
      }
    public float getDoanhSo() {
        return doanhSo;
    }

    public void setDoanhSo(float doanhSo) {
        this.doanhSo = doanhSo;
    }

    public float getHoaHong() {
        return hoaHong;
    }

    public void setHoaHong(float hoaHong) {
        this.hoaHong = hoaHong;
    }

  
 }