package assignment;
import java.util.*;
public class nhap {
 public String fullname;
    public Float mark;
    public Double a;
    public void input()
{
    Scanner scanner = new Scanner(System.in);
    System.out.println("nhap so luong nhan vien: ");
    a = scanner.nextDouble();
   

System.out.println(" >> Truong: ");

fullname = scanner.nextLine();

System.out.println(" >> Diem: ");

mark = scanner.nextFloat();
    }
public void output()
{
    System.out.printf("Truong: %s\n",fullname);
    System.out.printf("Diem: %f",mark);
}
}

