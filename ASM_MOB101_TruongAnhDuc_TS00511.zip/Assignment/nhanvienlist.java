package assignment;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.*;
public class nhanvienlist {
          private final    ArrayList<nhanvien> arrnv = new ArrayList<>();

public void nhap()
{
            Scanner abc = new Scanner(System.in);
            arrnv.clear();
         
            do
            {
                System.out.println("Nhap loai nhan vien:  1/hanhchinh    2/ tiepthi     3/ truongphong");
                String loai =abc.nextLine();
                if(loai == null || loai.equals(""))
                    break;
                int iloai = Integer.parseInt(loai);
                switch (iloai)
                {
                    case 1:
                        hanhchinh hc =new hanhchinh();
                       hc.nhap(abc);
                       arrnv.add(hc);
                        break;
                    case 2 :
                        tiepthi tt =new tiepthi();
                        tt.nhap(abc);
                       arrnv.add(tt);
                       break;
                    case 3 :
                        truongphong tp =new truongphong();
                        tp.nhap(abc);
                       arrnv.add(tp);
                       break;
                }
            }
            while( true);
        
}
public void xuat(){
    System.out.println("Danh sach nhan vien");
    for(nhanvien nv : arrnv){
    if(nv instanceof hanhchinh hanhChinh){
            hanhChinh.xuat();
    }else if(nv instanceof tiepthi tiepThi){
        tiepThi.xuat();
    }else if(nv instanceof truongphong truongPhong){
        truongPhong.xuat();
}
        System.out.println("\n------------------------------");
    }
}          
public void timvakiem(Scanner abc){
    System.out.println("nhap ma muon kiem:");
    String ma=abc.next();
    nhanvien nvFound = null;
    for(nhanvien nv : arrnv)
    {
        if(nv.getMaNV().equalsIgnoreCase(ma)){
              nvFound = nv;
              break;
        }}
        if(nvFound !=null){
            System.out.println("thong tin nha vien :");
            nvFound.xuat();
        }else{
            System.out.println("khong kiem duoc ");
        }
    }
public void xoa(Scanner s)
{
    System.out.println("xoa thong tin");
    System.out.println("nhap ma:");
    String ma = s.nextLine();
    nhanvien kiem =null;
    for(nhanvien nv : arrnv)
    {
        if(nv.getMaNV().equalsIgnoreCase(ma))
        {
            kiem = nv;
            break;
        }
    }
    if(kiem !=null){
        arrnv.remove(kiem);
        System.out.println("da xoa");
    }else{
        System.out.printf("nhap vien ko tim thay trong danh sach  co ma  %f",ma);
    }
}
public void capnhat(Scanner s){
       System.out.println("nhap ma nhan vien:");
    String ma=s.next();
    nhanvien nvFound = null;
    for(nhanvien item : arrnv)
    {
        if(item.getMaNV().equalsIgnoreCase(ma)){
              nvFound = item;
              break;
        }}
        if(nvFound !=null){
            if(nvFound instanceof hanhchinh)
            {
                 ((hanhchinh) nvFound).nhap(s);
            }else if(nvFound instanceof tiepthi)
            {
                 ((tiepthi) nvFound).nhap(s);

            }else if (nvFound instanceof truongphong)
            {
                 ((truongphong) nvFound).nhap(s);

            }
        }
        else{System.out.println("khong kiem thay ma");}
    }
public void kiemtheoluong(Scanner s){
    System.out.println("tim nhan vien theo luong");
    System.out.println("nhap luong cao ");
 float min = s.nextFloat();
    System.out.println("nhap luong cao nhat");
    float max=s.nextFloat();
    boolean found = false;
    for(nhanvien nhanvien: arrnv){
    if(min<=nhanvien.getLuong() && nhanvien.getLuong()<=max)
    {
        nhanvien.xuat();
        System.out.println("");
        found=true;
    }
    }
    if(found == false){
        System.out.println("khong co nhan vien ");
    }
}
 public void sapXepTheoHoTen() {
        Collections.sort(arrnv, new Comparator<nhanvien>() {
            @Override
            public int compare(nhanvien nv1, nhanvien nv2) {
                return nv1.getHoTen().compareTo(nv2.getHoTen());
            }
        });

        System.out.println("Danh sach nhan vien đa đuoc sap xep theo ho va ten:");
        for (nhanvien nhanVien : arrnv) {
            nhanVien.xuat();
            System.out.println();
        }
    }

    public void sapXepTheoThuNhap() {
        Collections.sort(arrnv, new Comparator<nhanvien>() {
            @Override
            public int compare(nhanvien nv1, nhanvien nv2) {
                if (nv1.getLuong() < nv2.getLuong()) {
                    return 1;
                } else if (nv1.getLuong() > nv2.getLuong()) {
                    return -1;
                }
                return 0;
            }
        });

        System.out.println("Danh sach nhan vien đa đuoc sap xep theo thu nhap:");
        for (nhanvien nhanVien : arrnv) {
            nhanVien.xuat();
            System.out.println();
        }
    }

    public void xuat5nhanvienCoThuNhapCaoNhat() {
        Collections.sort(arrnv, new Comparator<nhanvien>() {
            @Override
            public int compare(nhanvien nv1, nhanvien nv2) {
                if (nv1.getLuong() < nv2.getLuong()) {
                    return 1;
                } else if (nv1.getLuong() > nv2.getLuong()) {
                    return -1;
                }
                return 0;
            }
        });

        System.out.println("5 nhan vien co thu nhap cao nhat:");
        int count = Math.min(5, arrnv.size());
        for (int i = 0; i < count; i++) {
            arrnv.get(i).xuat();
            System.out.println();
        }
    }
}