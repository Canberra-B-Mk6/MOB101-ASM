package assignment;
import java.util.*;
public class nhanvien {
    String maNV;
     String hoTen;
     String loai;
      float luong;    

    public nhanvien() {
    }
     
     
     public nhanvien(String maNV,String  hoTen, String loai, float luong){
        this.maNV=maNV;
         this.hoTen=hoTen;
         this.luong=luong;
         this.loai=loai;
     }
     public void nhap(Scanner abc){
         System.out.println("Ma nhan vien");
         this.maNV= abc.nextLine();
         System.out.println("Ho ten");
         this.hoTen= abc.nextLine();
         System.out.println(" Luong");
         this.luong= abc.nextFloat();
          abc.nextLine();
     }

     public void xuat(){
         System.out.printf("ma: %s   ; hoten: %s    ;loai: %s   ; luong:  %f",maNV,hoTen,loai,luong);
     }
    public String getMaNV() {
        return maNV;
    }

    public void setMaNV(String maNV) {
        this.maNV = maNV;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getLoai() {
        return loai;
    }

    public void setLoai(String loai) {
        this.loai = loai;
    }

    public float getLuong() {
        return luong;
    }

    public void setLuong(float luong) {
        this.luong = luong;
    }

   
     
     
     public double thueThuNhap()
     {
     if(this.luong < 9000000) return 0;
     else if(this.luong<15000000) 
         return (this.luong-9000000)*10/100;
     else
         return (this.luong-15000000)*12/100;
             }}