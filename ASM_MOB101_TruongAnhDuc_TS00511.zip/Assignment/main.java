package assignment;
import java.util.*;
public class main{
    public static void main(String args[]) {
        Scanner scanner = new Scanner(System.in);
        employee em = new employee(0,,0);
        
        em.input(scanner);
        em.output();
    }
}
