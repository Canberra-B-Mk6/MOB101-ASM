package assignment;
import java.util.ArrayList;
import java.util.Scanner;

public class assignment1 {
    public static void main(String args[]) {
        ArrayList<nhanvien> arrnv = new ArrayList<>();
        int menu;
           Scanner abc = new Scanner(System.in);
            nhanvienlist ds=new nhanvienlist();

        do {
            System.out.println("  +------------------------ ASSIGNMENT -----------------------------+");
            System.out.println("   |  1. Nhap danh sach nhan vien tu ban phim.\n                            |  ");
            System.out.println("   |  2.Xuat danh sach nhan vien ra   man hinh\n                             |");
            System.out.println("   |  3. hien thi nhan vien nhap tu ban phim\n |");
            System.out.println("   |  4. Xoa nhan vien nhap tu ban phim\n                         |");
            System.out.println("   |  5. Cap nhat thong tin nhan vien nhap tu ban phim \n |");
            System.out.println("   |  6. Tim cac nhan vien theo khoan luong nhap tu ban phim.\n|" );
            System.out.println("   |  7. Sap xep nhan vien theo ho ten    .\n                                      |");
            System.out.println("   |  8. Sap xep nhan vien theo thu nhap    .\n                                  |" );
            System.out.println("   |  9. 5 nhan vien co muc thu nhap cao nhat                        |");
            System.out.println("   |  10. thoat                        |");
            System.out.println("  +---------------------------------------------------------------------+");
            System.out.println("moi nhap so");
            menu = abc.nextInt();
       
 

        switch (menu) {
            case 1 -> {
                System.out.println("nhap danh sach");
                    ds.nhap();
                    break;
            }
            case 2 -> {
                System.out.println("xuat  danh sach");
             ds.xuat();
            }
            case 3 -> {System.out.println("hien thi nv");
            ds.timvakiem(abc);
            break;
            }
            case 4 -> {System.out.println("xoa nv");
            ds.xoa(abc);
            break;
            
            }
            case 5 ->{ System.out.println("cap nhat thong tin");
            ds.capnhat(abc);
            break;
            
            }
            case 6 ->{ System.out.println("tim nv theo luong");
            ds.kiemtheoluong(abc);
            break;
            
            }
            case 7 -> {System.out.println("xap xep theo ten");
            ds.sapXepTheoHoTen();
            break;
            
            }
            case 8 -> {System.out.println("xap xep theo thu nhap");
            ds.sapXepTheoThuNhap();
            break;
            
            }
            case 9 -> {System.out.println("nv thu nhap cao nhat");
            ds.xuat5nhanvienCoThuNhapCaoNhat();
            break;
            }
              case 10 -> {
            System.exit(0);
            }
        }
    }
     while (true);
    }
        }
    