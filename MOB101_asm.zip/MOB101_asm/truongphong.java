package assignment;

import java.util.Scanner;

public class truongphong extends nhanvien {
     public double trachnhiem;

    public truongphong() {
    }
     
    public  truongphong (String maNV,String  hoTen, String loai, float luong,double trachnhiem)
    {
         super(maNV,hoTen,"truongphong",luong);
        this.trachnhiem=trachnhiem;
        
    }

          public void nhap(Scanner abc){
          super.nhap(abc);
              System.out.println("trachnhiem:");
              this.trachnhiem=abc.nextDouble();
              abc.nextLine();
          }
          public void xuat(){
              super.xuat();
              System.out.printf("Luong trach nhiem : %f",trachnhiem);
          }
    public double getTrachnhiem() {
        return trachnhiem;
    }

    public void setTrachnhiem(double trachnhiem) {
        this.trachnhiem = trachnhiem;
    }
 }
