import assignment.hanhchinh;
import assignment.nhanvien;
import assignment.tiepthi;
import assignment.truongphong;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
public class DanhSachNhanVien {
          public final ArrayList<nhanvien> arrnv = new ArrayList<>();

public void nhap()
{
            Scanner abc = new Scanner(System.in);
            arrnv.clear();
         
            do
            {
                System.out.println("Nhap loai nhan vien:  1/hanhchinh    2/ tiepthi     3/ truongphong");
                String loai =abc.nextLine();
                if(loai == null || loai.equals(""))
                    break;
                int iloai = Integer.parseInt(loai);
                switch (iloai)
                {
                    case 1:
                        hanhchinh hc =new hanhchinh();
                       hc.nhap(abc);
                       arrnv.add(hc);
                        break;
                    case 2 :
                        tiepthi tt =new tiepthi();
                        tt.nhap(abc);
                       arrnv.add(tt);
                       break;
                    case 3 :
                        truongphong tp =new truongphong();
                        tp.nhap(abc);
                       arrnv.add(tp);
                       break;
                }
            }
            while( true);
        
}
public void xuat(){
    System.out.println("Danh sach nhan vien");
    for(nhanvien nv : arrnv){
    if(nv instanceof hanhchinh hanhChinh){
            hanhChinh.xuat();
    }else if(nv instanceof tiepthi tiepThi){
        tiepThi.xuat();
    }else if(nv instanceof truongphong truongPhong){
        truongPhong.xuat();
}
        System.out.println("\n------------------------------");
    }
}          
public void timvakiem(Scanner abc){
    System.out.println("nhap ma muon kiem:");
    String ma=abc.next();
    nhanvien nvFound = null;
    for(nhanvien nv : arrnv)
    {
        if(nv.getMaNV().equalsIgnoreCase(ma)){
              nvFound = nv;
              break;
        }}
        if(nvFound !=null){
            System.out.println("thong tin nha vien :");
            nvFound.xuat();
        }else{
            System.out.println("khong kiem duoc ");
        }
    }
public void xoa(Scanner s)
{
    System.out.println("xoa thong tin");
    System.out.println("nhap ma:");
    String ma = s.nextLine();
    nhanvien kiem =null;
    for(nhanvien nv : arrnv)
    {
        if(nv.getMaNV().equalsIgnoreCase(ma))
        {
            kiem = nv;
            break;
        }
    }
    if(kiem !=null){
        arrnv.remove(kiem);
        System.out.println("da xoa");
    }else{
        System.out.printf("nhap vien ko tim thay trong danh sach  co ma  %f",ma);
    }
}
public void capnhat(Scanner s){
       System.out.println("nhap ma nhan vien:");
    String ma=s.next();
    nhanvien nvFound = null;
    for(nhanvien item : arrnv)
    {
        if(item.getMaNV().equalsIgnoreCase(ma)){
              nvFound = item;
              break;
        }}
        if(nvFound !=null){
            if(nvFound instanceof hanhchinh)
            {
                 ((hanhchinh) nvFound).nhap(s);
            }else if(nvFound instanceof tiepthi)
            {
                 ((tiepthi) nvFound).nhap(s);

            }else if (nvFound instanceof truongphong)
            {
                 ((truongphong) nvFound).nhap(s);

            }
        }
        else{System.out.println("khong kiem thay ma");}
    }
public void kiemtheoluong(Scanner s){
    System.out.println("tim nhan vien theo luong");
    System.out.println("nhap luong cao ");
 float min = s.nextFloat();
    System.out.println("nhap luong cao nhat");
    float max=s.nextFloat();
    boolean found = false;
    for(nhanvien nhanvien: arrnv){
    if(min<=nhanvien.getLuong() && nhanvien.getLuong()<=max)
    {
        nhanvien.xuat();
        System.out.println("");
        found=true;
    }
    }
    if(found == false){
        System.out.println("khong co nhan vien ");
    }
}
 public void sapXepTheoHoTen() {
        Collections.sort(arrnv, new Comparator<nhanvien>() {
            @Override
            public int compare(nhanvien nv1, nhanvien nv2) {
                return nv1.getHoTen().compareTo(nv2.getHoTen());
            }
        });

        System.out.println("Danh sach nhan vien đa đuoc sap xep theo ho va ten:");
        for (nhanvien nhanVien : arrnv) {
            nhanVien.xuat();
            System.out.println();
        }
    }

    public void sapXepTheoThuNhap() {
        Collections.sort(arrnv, new Comparator<nhanvien>() {
            @Override
            public int compare(nhanvien nv1, nhanvien nv2) {
                if (nv1.getLuong() < nv2.getLuong()) {
                    return 1;
                } else if (nv1.getLuong() > nv2.getLuong()) {
                    return -1;
                }
                return 0;
            }
        });

        System.out.println("Danh sach nhan vien đa đuoc sap xep theo thu nhap:");
        for (nhanvien nhanVien : arrnv) {
            nhanVien.xuat();
            System.out.println();
        }
    }

    public void xuat5nhanvienCoThuNhapCaoNhat() {
        Collections.sort(arrnv, new Comparator<nhanvien>() {
            @Override
            public int compare(nhanvien nv1, nhanvien nv2) {
                if (nv1.getLuong() < nv2.getLuong()) {
                    return 1;
                } else if (nv1.getLuong() > nv2.getLuong()) {
                    return -1;
                }
                return 0;
            }
        });

        System.out.println("5 nhan vien co thu nhap cao nhat:");
        int count = Math.min(5, arrnv.size());
        for (int i = 0; i < count; i++) {
            arrnv.get(i).xuat();
            System.out.println();
        }
    }
}

public class Assignment1 {
    public static void main(String args[]) {
        ArrayList<NhanVien> arrNV = new ArrayList<>();
        int menu;
        Scanner abc = new Scanner(System.in);
        NhanVienList ds = new NhanVienList();

        do {
            System.out.println("  +------------------------ ASSIGNMENT -----------------------------+");
            System.out.println("   |  1. Nhap danh sach nhan vien tu ban phim.\n                            |  ");
            System.out.println("   |  2.Xuat danh sach nhan vien ra man hinh\n                             |");
            System.out.println("   |  3. Hien thi nhan vien nhap tu ban phim\n |");
            System.out.println("   |  4. Xoa nhan vien nhap tu ban phim\n                         |");
            System.out.println("   |  5. Cap nhat thong tin nhan vien nhap tu ban phim \n |");
            System.out.println("   |  6. Tim cac nhan vien theo khoan luong nhap tu ban phim.\n|" );
            System.out.println("   |  7. Sap xep nhan vien theo ho ten    .\n                                      |");
            System.out.println("   |  8. Sap xep nhan vien theo thu nhap    .\n                                  |" );
            System.out.println("   |  9. 5 nhan vien co muc thu nhap cao nhat                        |");
            System.out.println("   |  10. Thoat                        |");
            System.out.println("  +---------------------------------------------------------------------+");
            System.out.println("Moi nhap so:");
            menu = abc.nextInt();

            switch (menu) {
                case 1:
                    System.out.println("Nhap danh sach:");
                    ds.nhap();
                    break;
                case 2:
                    System.out.println("Xuat danh sach:");
                    ds.xuat();
                    break;
                case 3:
                    System.out.println("Hien thi nhan vien:");
                    ds.timVaKiem(abc);
                    break;
                case 4:
                    System.out.println("Xoa nhan vien:");
                    ds.xoa(abc);
                    break;
                case 5:
                    System.out.println("Cap nhat thong tin nhan vien:");
                    ds.capnhat(abc);
                    break;
                case 6:
                    System.out.println("Tim nhan vien theo luong:");
                    ds.kiemTheoLuong(abc);
                    break;
                case 7:
                    System.out.println("Sap xep nhan vien theo ho ten:");
                    ds.sapXepTheoHoTen();
                    break;
                case 8:
                    System.out.println("Sap xep nhan vien theo thu nhap:");
                    ds.sapXepTheoThuNhap();
                    break;
                case 9:
                    System.out.println("5 nhan vien co muc thu nhap cao nhat:");
                    ds.xuat5NhanVienCoThuNhapCaoNhat();
                    break;
                case 10:
                    System.exit(0);
            }
        } while (true);
    }
}
